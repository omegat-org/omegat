package com.martiansoftware.jsap.examples;

// @@snip:Manual_HelloWorld_1@@
public class Manual_HelloWorld_1 {

	public static void main(String[] args){
		System.out.println("Hello, World!");
	}
}
// @@endSnip@@