#!/bin/sh

java -jar "$(dirname "$0")/SuperTMXMerge.jar" "$@"