package org.dts.spell.dictionary.myspell;

class AffixHeader
{
  public char achar ;
  public char type ;
  public short ff ;
  public int numents ;
}