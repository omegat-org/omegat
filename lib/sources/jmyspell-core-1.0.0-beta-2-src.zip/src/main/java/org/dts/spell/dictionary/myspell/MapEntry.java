/*
 * Created on 27/12/2004
 *
 */
package org.dts.spell.dictionary.myspell;

/**
 * @author DreamTangerine
 *
 */
public class MapEntry
{
  String set ;
}
