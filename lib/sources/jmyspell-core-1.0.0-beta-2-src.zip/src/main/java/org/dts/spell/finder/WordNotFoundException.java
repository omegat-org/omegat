package org.dts.spell.finder;

public class WordNotFoundException extends RuntimeException {

  /**
   * Creates a new WordNotFoundException object.
   */
  public WordNotFoundException() {
    super();
  }
}
