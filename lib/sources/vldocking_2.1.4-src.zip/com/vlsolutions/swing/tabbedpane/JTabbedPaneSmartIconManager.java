/*
    VLDocking Framework 2.1
    Copyright VLSOLUTIONS, 2004-2006

    email : info@vlsolutions.com
------------------------------------------------------------------------
This software is distributed under the CeCILL license, a GNU GPL-compatible
license adapted to french law.
French and English license headers are provided at the begining of
the source files of this software application.
------------------------------------------------------------------------
LICENCE CeCILL (FRENCH VERSION).
------------------------------------------------------------------------
Ce logiciel est un programme informatique servant � am�liorer les interfaces
homme-machine d'applications Java bas�es sur Swing, en leur apportant un
ensemble de fonctions relatives au dockage des composants.

Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
respectant les principes de diffusion des logiciels libres. Vous pouvez
utiliser, modifier et/ou redistribuer ce programme sous les conditions
de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
sur le site "http://www.cecill.info".

En contrepartie de l'accessibilit� au code source et des droits de copie,
de modification et de redistribution accord�s par cette licence, il n'est
offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
titulaire des droits patrimoniaux et les conc�dants successifs.

A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
associ�s au chargement,  � l'utilisation,  � la modification et/ou au
d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
avertis poss�dant  des  connaissances  informatiques approfondies.  Les
utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
logiciel � leurs besoins dans des conditions permettant d'assurer la
s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
� l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
pris connaissance de la licence CeCILL, et que vous en avez accept� les
termes.

------------------------------------------------------------------------
CeCILL License (ENGLISH VERSION)
------------------------------------------------------------------------

This software is a computer program whose purpose is to enhance Human-Computer
Interfaces written in Java with the Swing framework, providing them a set of
functions related to component docking.

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use,
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info".

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability.

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or
data to be ensured and,  more generally, to use and operate it in the
same conditions as regards security.

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

*/


package com.vlsolutions.swing.tabbedpane;

import java.awt.Component;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.Icon;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;

/** This class is the interface between a JTabbedPane and a smart icon.
 *<p>
 * As JTabbedPanes cannot use any JComponents as tab selectors (the access if protected and we just have
 * a label, an icon and a tooltip), we have to rely on tricks to bypass them. 
 * <p>
 * This class is used (with a mouse listener) to forward events into the smart icon. which is responsible
 * for faking an enhanced tab selector (including label and optional buttons).
 *
 *
 * @author Lilian Chamontin, VLSolutions
 */
public class JTabbedPaneSmartIconManager implements MouseListener, MouseMotionListener {
  
  private JTabbedPane tabbedPane;
  
  private JTabbedPaneSmartIcon pressedIcon;
  private int pressedTab; // the tab associated to the pressed icon  

  private JTabbedPaneSmartIcon movedIcon;
  private int movedTab;
  
  /** Constructs a new tabbedPane manager for a given JTabbedPane */
  public JTabbedPaneSmartIconManager(JTabbedPane tabbedPane) {
    this.tabbedPane = tabbedPane;
    tabbedPane.addMouseListener(this);
    tabbedPane.addMouseMotionListener(this);
  }

  /** MouseListener implementation, use to track mouse behaviour inside the tab selector bounds
   * and forward them to the appropriate smart icon.
   */
  public void mouseReleased(MouseEvent e) {
    checkTabCount();
    // forward the event to the pressed smart icon
    if (pressedIcon != null){
      Point p = e.getPoint();
      
      final Rectangle r = tabbedPane.getBoundsAt(pressedTab);
      Point iPoint = convertPointToIcon(r, p, pressedIcon);
      
      final MouseEvent eSmart = new MouseEvent(
            (Component) e.getSource(), e.getID(), e.getWhen(), e.getModifiers(),
            iPoint.x, iPoint.y, e.getClickCount(), e.isPopupTrigger(), e.getButton());
      try {
        if (pressedIcon.onMouseReleased(eSmart)){
          tabbedPane.repaint(r.x, r.y, r.width, r.height); // no choice but trigger a repaint        
        }
      } catch (Exception ignore){ // bug database : 5075526 this is to remove the stack trace        
      }
      pressedIcon = null;
    }    
  }

  private Point convertPointToIcon(Rectangle r, Point p, Icon icon){
    int x = p.x - (r.x + r.width/2 - icon.getIconWidth()/2) ;
    int y = p.y - (r.y + r.height/2 - icon.getIconHeight()/2);
    return new Point(x, y);
  }

  
  /** MouseListener implementation, use to track mouse behaviour inside the tab selector bounds
   * and forward them to the appropriate smart icon.
   */
  public void mousePressed(MouseEvent e) {
    // where is the mouse pressed ?
    Point p = e.getPoint();
    
    this.pressedIcon = null; // reset the pressed state
    
    int targetTab = findTabAt(p);
    if (targetTab != -1){
      Icon icon = tabbedPane.getIconAt(targetTab);
      if (icon instanceof JTabbedPaneSmartIcon){
        JTabbedPaneSmartIcon smartIcon = (JTabbedPaneSmartIcon) icon;
        // convert point into smartIcon coordinates
                
        // get the tab bounds
        Rectangle r = tabbedPane.getBoundsAt(targetTab);
        
        // as the icon is the only thing visible, we consider it centered in the tab
        // (which is the default paint behaviour of BasicTabbedPaneUI, and should be okay
        // with most look and feels.
        int x = p.x - (r.x + r.width/2 - icon.getIconWidth()/2) ;
        int y = p.y - (r.y + r.height/2 - icon.getIconHeight()/2);
        if (x >=0 && y >= 0 && x < icon.getIconWidth() && y < icon.getIconHeight()){
          // forward the event to the smart icon
          MouseEvent eSmart = new MouseEvent(
              (Component) e.getSource(), e.getID(), e.getWhen(), e.getModifiers(),
              x, y, e.getClickCount(), e.isPopupTrigger(), e.getButton());
          if (smartIcon.onMousePressed(eSmart)){
            tabbedPane.repaint(r.x, r.y, r.width, r.height); // no choice but trigger a repaint          
          }
          pressedIcon = smartIcon;
          pressedTab = targetTab;
        } 
      } 
    }
  }

  /** verify if the tab count hasn't changed. 
   *<p>
   * There is always the risk that the last tab has been removed (and movedTab will be
   * out of bounds)
   *
   */
  private void checkTabCount(){
    if (movedTab >= tabbedPane.getTabCount()){ // too late : tab has been removed
      movedTab = -1;
      movedIcon = null;
    }
    if (pressedTab >= tabbedPane.getTabCount()){
      pressedTab = -1;
      pressedIcon = null;
    }
  }

  private int findTabAt(Point p){
    int x= p.x;
    int y = p.y;
    for (int i=0; i < tabbedPane.getTabCount(); i++){
      if (tabbedPane.getBoundsAt(i).contains(x, y)){
        return i;
      }
    }
    return -1;
  }
  
  
  /** MouseListener implementation, use to track mouse behaviour inside the tab selector bounds
   * and forward them to the appropriate smart icon.
   */
  public void mouseMoved(MouseEvent e) {
    checkTabCount();

    // where is the mouse moved ?
    Point p = e.getPoint();
    
    int targetTab = findTabAt(p);
    if (targetTab != -1){
      Icon icon = tabbedPane.getIconAt(targetTab);
      if (icon instanceof JTabbedPaneSmartIcon){
        JTabbedPaneSmartIcon smartIcon = (JTabbedPaneSmartIcon) icon;
        if (movedIcon != null && movedIcon != smartIcon){
          // trigger a mouseExit from the movedIcon
          Rectangle prevRect = tabbedPane.getBoundsAt(movedTab);
          Point iPoint = convertPointToIcon(prevRect, p, movedIcon);
          MouseEvent eSmart = new MouseEvent(
              (Component) e.getSource(), MouseEvent.MOUSE_EXITED, e.getWhen(), e.getModifiers(),
              iPoint.x, iPoint.y, e.getClickCount(), e.isPopupTrigger(), e.getButton());
          if (movedIcon.onMouseExited(eSmart)){
            String tip = movedIcon.getLocalTooltipText(); 
            if (tip != null && ! tip.equals(tabbedPane.getToolTipTextAt(targetTab))){
              tabbedPane.setToolTipTextAt(targetTab, tip);
            }
//            tabbedPane.repaint(prevRect.x, prevRect.y, prevRect.width, prevRect.height); 
           tabbedPane.revalidate(); 
           tabbedPane.repaint(); 
          }
          movedIcon = null;
          movedTab = -1;
        }
        
        // convert point into smartIcon coordinates
        // get the tab bounds
        Rectangle r = tabbedPane.getBoundsAt(targetTab);
        Point iPoint = convertPointToIcon(r, p, icon);
        
        if (iPoint.x >=0 && iPoint.y >= 0 
            && iPoint.x < icon.getIconWidth() 
            && iPoint.y < icon.getIconHeight()){
          // forward the event to the smart icon
          MouseEvent eSmart = new MouseEvent(
              (Component) e.getSource(), e.getID(), e.getWhen(), e.getModifiers(),
              iPoint.x, iPoint.y, e.getClickCount(), e.isPopupTrigger(), e.getButton());
          if (smartIcon.onMouseMoved(eSmart)){
            String tip = smartIcon.getLocalTooltipText();
            if (tip != null && ! tip.equals(tabbedPane.getToolTipTextAt(targetTab))){
              tabbedPane.setToolTipTextAt(targetTab, tip);
            }
           tabbedPane.revalidate(); 
           tabbedPane.repaint(); 
//            tabbedPane.repaint(r.x, r.y, r.width, r.height); 
          }
          movedIcon = smartIcon;
          movedTab = targetTab;
        } else { // in tab, but not on icon
          if (movedIcon != null){
            // trigger a mouseExit from the movedIcon
            Rectangle prevRect = tabbedPane.getBoundsAt(movedTab);
            iPoint = convertPointToIcon(prevRect, p, movedIcon);
            MouseEvent eSmart = new MouseEvent(
                (Component) e.getSource(), MouseEvent.MOUSE_EXITED, e.getWhen(), e.getModifiers(),
                iPoint.x, iPoint.y, e.getClickCount(), e.isPopupTrigger(), e.getButton());
            if (movedIcon.onMouseExited(eSmart)){
              String tip = movedIcon.getLocalTooltipText();
              if (tip != null && ! tip.equals(tabbedPane.getToolTipTextAt(targetTab))){
                tabbedPane.setToolTipTextAt(targetTab, tip);
              }

           tabbedPane.revalidate(); 
           tabbedPane.repaint(); 
//            tabbedPane.repaint(prevRect.x, prevRect.y, prevRect.width, prevRect.height); 
            }
          }          
          movedIcon = null;
          movedTab = -1;
        } 
      } else { // not a smart icon ? 
        if (movedIcon != null){
          // trigger a mouseExit from the movedIcon
          Rectangle prevRect = tabbedPane.getBoundsAt(movedTab);
          Point iPoint = convertPointToIcon(prevRect, p, movedIcon);
          MouseEvent eSmart = new MouseEvent(
              (Component) e.getSource(), MouseEvent.MOUSE_EXITED, e.getWhen(), e.getModifiers(),
              iPoint.x, iPoint.y, e.getClickCount(), e.isPopupTrigger(), e.getButton());
          if (movedIcon.onMouseExited(eSmart)){
            String tip = movedIcon.getLocalTooltipText();
            if (tip != null && ! tip.equals(tabbedPane.getToolTipTextAt(targetTab))){
              tabbedPane.setToolTipTextAt(targetTab, tip);
            }

           tabbedPane.revalidate(); 
           tabbedPane.repaint(); 
//          tabbedPane.repaint(prevRect.x, prevRect.y, prevRect.width, prevRect.height); 
          }
          movedIcon = null;
          movedTab = -1;
        }
      } 
    } else { // not on a tab
      if (movedIcon != null){
        // trigger a mouseExit from the movedIcon
        Rectangle prevRect = tabbedPane.getBoundsAt(movedTab);
        Point iPoint = convertPointToIcon(prevRect, p, movedIcon);
        MouseEvent eSmart = new MouseEvent(
            (Component) e.getSource(), MouseEvent.MOUSE_EXITED, e.getWhen(), e.getModifiers(),
            iPoint.x, iPoint.y, e.getClickCount(), e.isPopupTrigger(), e.getButton());
        if (movedIcon.onMouseExited(eSmart)){
          String tip = movedIcon.getLocalTooltipText();
          if (tip != null && ! tip.equals(tabbedPane.getToolTipTextAt(movedTab))){
            tabbedPane.setToolTipTextAt(movedTab, tip);
          }
          
           tabbedPane.revalidate(); 
           tabbedPane.repaint(); 
//        tabbedPane.repaint(prevRect.x, prevRect.y, prevRect.width, prevRect.height); 
        }
        movedIcon = null;
        movedTab = -1;
      }
    }     

  }

  /** MouseListener implementation, use to track mouse behaviour inside the tab selector bounds
   * and forward them to the appropriate smart icon.
   */
  public void mouseExited(MouseEvent e) {
    checkTabCount();
    if (movedIcon != null){
      Point p = e.getPoint();
      // trigger a mouseExit from the movedIcon
      Rectangle prevRect = tabbedPane.getBoundsAt(movedTab);
      Point iPoint = convertPointToIcon(prevRect, p, movedIcon);
      MouseEvent eSmart = new MouseEvent(
          (Component) e.getSource(), MouseEvent.MOUSE_EXITED, e.getWhen(), e.getModifiers(),
          iPoint.x, iPoint.y, e.getClickCount(), e.isPopupTrigger(), e.getButton());
      if (movedIcon.onMouseExited(eSmart)){
        String tip = movedIcon.getLocalTooltipText();
        if (tip != null && ! tip.equals(tabbedPane.getToolTipTextAt(movedTab))){
          tabbedPane.setToolTipTextAt(movedTab, tip);
        }
        
        tabbedPane.repaint(prevRect.x, prevRect.y, prevRect.width, prevRect.height);
      }
      movedIcon = null;
      movedTab = -1;      
    }
    
  }

  /** MouseListener implementation, not used.
   */
  public void mouseEntered(MouseEvent e) {
  }

  /** MouseMotionListener implementation, not used.
   */
  public void mouseDragged(MouseEvent e) {
  }

  /** MouseListener implementation, not used.
   */
  public void mouseClicked(MouseEvent e) {
  }
  
}
