This archive contains the fr-classique.{aff,dic} and readme files from
http://www.dicollecte.org/download/fr/hunspell-french-dictionaries-v5.6.zip
